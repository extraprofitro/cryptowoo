<?php
/**
 * CryptoWoo Admin Notice class
 *
 * @package CryptoWoo
 * @deprecated Use class-cw-admin-notice.php instead
 */

// silence.

require_once CWOO_PLUGIN_DIR . '/admin/class-cw-admin-notice.php';
