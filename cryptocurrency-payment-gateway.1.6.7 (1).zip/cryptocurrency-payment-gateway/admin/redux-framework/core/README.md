# Shim directory for old integrations.

We found a number of theme developers tried including files directly. To alleviate issues with this we've created this 
shadow directory.
